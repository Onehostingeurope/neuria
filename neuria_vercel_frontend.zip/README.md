# NEURIA Frontend
Déploiement simple sur Vercel.